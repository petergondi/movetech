        <footer class="site-footer" style="bottom:0px">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 2019 4 PAY
                    </div>
                    <div class="col-sm-6 text-right">
                        <!-- Designed by <a href="https://www.movetechsolutions.com/">Movetech</a> -->
                    </div>
                </div>
            </div>
        </footer>